def add(a, b):
    """Returns the sum of a and b."""
    return a + b

def subtract(a, b):
    """Returns the difference of a and b."""
    return a - b

def multiply(a, b):
    """Returns the product of a and b."""
    return a * b

def divide(a, b):
    """Returns the quotient of a and b. Raises ZeroDivisionError if b is 0."""
    if b == 0:
        raise ZeroDivisionError("Error: Division by zero is not allowed.")
    return a / b

def get_number(prompt):
    """Prompts the user until a valid numeric input is provided."""
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Invalid input. Please enter a valid number.")

def get_operator():
    """Prompts the user for a valid operator or command."""
    valid_ops = {'+', '-', '*', '×', '/', '÷', 'c', 'clear', 'q', 'quit'}
    while True:
        op = input("Enter operator (+, -, ×, ÷, clear, quit): ").strip().lower()
        if op in valid_ops:
            # Normalize symbols for internal processing
            if op == '×':
                return '*'
            if op == '÷':
                return '/'
            return op
        print("Invalid operator. Please choose from +, -, ×, ÷, clear, quit.")

def calculator():
    # print("=======================================")
    # print("      COMMAND-LINE CALCULATOR          ")
    # print("=======================================")
    print("Operations:  + (Add) | - (Subtract)")
    print("             × (Multiply) | ÷ (Divide)")
    print("Commands:    clear (Reset) | quit (Exit)\n")
    
    current_val = None
    
    while True:
        if current_val is None:
            current_val = get_number("Enter first number: ")
        
        op = get_operator()
        
        if op in ('q', 'quit'):
            print("Exiting calculator. Goodbye!")
            break
        elif op in ('c', 'clear'):
            current_val = None
            print("\n--- Calculator Cleared ---\n")
            continue
            
        next_val = get_number("Enter next number: ")
        
        try:
            if op == '+':
                current_val = add(current_val, next_val)
            elif op == '-':
                current_val = subtract(current_val, next_val)
            elif op == '*':
                current_val = multiply(current_val, next_val)
            elif op == '/':
                current_val = divide(current_val, next_val)
            display_val = int(current_val) if current_val.is_integer() else current_val
            print(f"--> Result: {display_val}\n")
            
        except ZeroDivisionError as e:
            print(f"\n{e}\n")
            continue
        print("What would you like to do next?")
        print(" [1] Continue using this result")
        print(" [2] Clear and start fresh")
        print(" [3] Quit")
        
        choice = input("Select option (1-3): ").strip()
        print()
        
        if choice == '3' or choice.lower() in ('q', 'quit'):
            print("Exiting calculator. Goodbye!")
            break
        elif choice == '2' or choice.lower() in ('c', 'clear'):
            current_val = None
            print("--- Calculator Cleared ---\n")

if __name__ == "__main__":
    calculator()